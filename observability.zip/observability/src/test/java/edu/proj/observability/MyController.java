package edu.proj.observability;

import org.springframework.stereotype.Component;

//@Component
public class MyController {
    @Override
    public String toString() {
        return "TESTED MyController{}";
    }
}
