package edu.proj.observability;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObservabilityApplicationTests {
	@Autowired
	MyController my;
	@Test
	void contextLoads() {
		System.out.println(my.toString());
	}
}
