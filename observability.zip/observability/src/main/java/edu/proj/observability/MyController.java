package edu.proj.observability;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.observation.annotation.Observed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;


@RestController
public class MyController {
    @Autowired
    CustomMetricsService service;
    @Autowired
    MeterRegistry meterRegistry;

    Logger log= LoggerFactory.getLogger(MyController.class);
    Random random = new Random();

    @GetMapping("/hello")
    @Observed(name = "user.result",contextualName = "user#result", lowCardinalityKeyValues = {"userType","alex"})
    public String result(String name){

        System.out.println(meterRegistry.getClass());
        log.info("there is name: {}", name);
        Gauge.builder("AAAA.some.value",()->777).register(meterRegistry);
        //service.incrementCustomMetric();
        System.out.println("tested");
        return "Hello friend!";
    }
    @Override
    public String toString() {
        return "Normal MyController{}";
    }
}

@Component
class CustomMetricsService {

    private final Counter customMetricCounter;

    public CustomMetricsService(MeterRegistry meterRegistry) {
        customMetricCounter = Counter.builder("custom_metric_name")
                .description("Description of custom metric")
                .tags("environment", "development")
                .register(meterRegistry);
    }

    public void incrementCustomMetric() {
        customMetricCounter.increment();
    }
}